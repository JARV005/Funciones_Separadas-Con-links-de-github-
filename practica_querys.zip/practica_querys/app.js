const express = require('express');
const { Pool } = require('pg');

const app = express();
app.use(express.json());

// Configura tu conexión a PostgreSQL
const pool = new Pool({
  user: 'root',
  host: '168.119.183.3',
  database: 'pedritooo',
  password: 's7cq453mt2jnicTaQXKT',
  port: 5432,
});

app.listen(3000, () => {
  console.log('Servidor corriendo en http://localhost:3000');
});

app.get("/students", async (req, res) => {
   try {
    let result = await pool.query("SELECT * FROM students");
    return res.json(result);
   } catch (error) {
      res.status().json({error : 'error'})
   }
});

app.get("/courses", async (req, res) => {
   try {
    let result = await pool.query("SELECT * FROM courses");
    return res.json(result);
   } catch (error) {
      res.status().json({error : 'error'})
   }
});

app.get("/teachers", async (req, res) => {
   try {
    let result = await pool.query("SELECT * FROM teachers");
    return res.json(result);
   } catch (error) {
      res.status().json({error : 'error'})
   }
});

app.get("/enrollments", async (req, res) => {
   try {
    let result = await pool.query("SELECT * FROM enrollments");
    return res.json(result);
   } catch (error) {
      res.status().json({error : 'error'})
   }
});

/* Ejercicio 2 */
app.get("/ejercicio-2", async (req, res) => {
   try {
    let result = await pool.query("SELECT courses.name, teachers.first_name, teachers.last_name FROM courses INNER JOIN teachers ON courses.teacher_id = teachers.id");
    return res.json(result);
   } catch (error) {
      res.status().json({error : 'error'})
   }
});

/* Ejercicio 3 */
app.get("/ejercicio-3", async (req, res) => {
   try {
    let result = await pool.query("SELECT courses.name course, teachers.specialization specialization FROM courses JOIN teachers ON courses.teacher_id = teachers.id ORDER BY course desc");
    return res.json(result);
   } catch (error) {
      res.status().json({error : 'error'})
   }
});

/* Ejercicio 4 */
app.get("/ejercicio-4", async (req, res) => {
   try {
    let result = await pool.query(`
        SELECT s.first_name, s.last_name, c.id as course_id, c.name as course, t.first_name as teacher
        FROM students s
        JOIN enrollments e ON s.id = e.student_id
        JOIN courses c ON c.id = e.course_id
        JOIN teachers t ON t.id = c.teacher_id`);
    return res.json(result);
   } catch (error) {
      res.status().json({error : 'error'})
   }
});

/* Ejercicio 5 */
app.get("/ejercicio-5", async (req, res) => {
   try {
    let result = await pool.query(`
        SELECT c.name course,
	    COUNT(e.student_id) students
        FROM enrollments e
        JOIN courses c ON c.id = e.course_id
        GROUP BY c.id, c.name
        `);
    return res.json(result);
   } catch (error) {
      res.status().json({error : 'error'})
   }
});

/* Post student*/
app.post('/students', async (req, res) => {
  const { first_name, last_name, email, document_number, gender, address, phone } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO students (first_name, last_name, email, document_number, gender, address, phone) VALUES ($1, $2, $3, $4, $5, $6, $7)',
      [first_name, last_name, email, document_number, gender, address, phone]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error al crear el usuario' });
  }
});

/* Post teacher*/
app.post('/teachers', async (req, res) => {
  const { first_name, last_name, email, document_number, specialization, hire_date, phone } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO teachers (first_name, last_name, email, document_number, specialization, hire_date, phone) VALUES ($1, $2, $3, $4, $5, $6, $7)',
      [first_name, last_name, email, document_number, specialization, hire_date, phone]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error al crear el usuario' });
  }
});

/* Post course */
app.post('/courses', async (req, res) => {
  const { name, code, description, teacher_id } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO courses (name, code, description, teacher_id) VALUES ($1, $2, $3, $4)',
      [name, code, description, teacher_id]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error al crear el usuario' });
  }
});

/* Post enrollment */
app.post('/enrollments', async (req, res) => {
  const { student_id, course_id } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO enrollments (student_id, course_id) VALUES ($1, $2)',
      [student_id, course_id]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error al crear el usuario' });
  }
});