const fs = require('fs');
const csv = require('csv-parser');
const { Client } = require('pg');

// DBsasa
const client = new Client({
  user: 'postgres',
  host: 'localhost',
  database: 'test',
  password: 'password',
  port: 5432,
});

async function cargarUsuariosDesdeCSV() {
  try {
    await client.connect();

    const usuarios = [];
    fs.createReadStream('db.csv')
      .pipe(csv())
      .on('data', (data) => {
        usuarios.push(data);
      })
      .on('end', async () => {
        for (const usuario of usuarios) {
          const query = `
            INSERT INTO usuarios (id, nombre, apellido, correo, edad, pais, telefono)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            ON CONFLICT (id) DO NOTHING;
          `;
          const values = [
            parseInt(usuario.id),
            usuario.nombre,
            usuario.apellido,
            usuario.correo,
            parseInt(usuario.edad),
            usuario.pais,
            usuario.telefono,
          ];
          await client.query(query, values);
        }

        console.log(' Usuarios cargados exitosamente.');
        await client.end();
      });

  } catch (err) {
    console.error('Error cargando usuarios:', err);
    await client.end();
  }
}

cargarUsuariosDesdeCSV();
